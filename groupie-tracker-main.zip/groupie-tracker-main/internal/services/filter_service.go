package services

// Minimal filter service placeholders.

// This file ensures the services package is visible to the Go tool.
var _ = 0
