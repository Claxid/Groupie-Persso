package services

// Minimal search service placeholders.

// This file ensures the services package is visible to the Go tool.
var _ = 0
