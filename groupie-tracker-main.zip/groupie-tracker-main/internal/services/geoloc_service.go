package services

// Minimal geolocation service placeholders.

// This file ensures the services package is visible to the Go tool.
var _ = 0
