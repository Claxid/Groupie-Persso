package handlers

// Handlers package contains HTTP handler implementations.

// This file is a minimal placeholder so the package is recognized by the go tool.
var _ = 0
