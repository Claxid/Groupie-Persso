package handlers

// Minimal search handler definitions.

// This file exists so the handlers package is buildable for tooling.
var _ = 0
