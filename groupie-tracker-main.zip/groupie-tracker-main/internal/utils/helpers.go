package utils

// Utility helpers used throughout the project (minimal placeholder).

// This file ensures the utils package is visible to the Go tool.
var _ = 0
