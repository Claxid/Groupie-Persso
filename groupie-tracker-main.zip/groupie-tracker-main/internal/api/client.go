package api

// Minimal client helpers for the api package.

// This file exists to make the package buildable for tooling.
var _ = 0
