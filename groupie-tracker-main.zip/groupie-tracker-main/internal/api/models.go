package api

// Package api contains API models used across the project.

// This file ensures the package directory is recognized by the Go toolchain.
var _ = 0
